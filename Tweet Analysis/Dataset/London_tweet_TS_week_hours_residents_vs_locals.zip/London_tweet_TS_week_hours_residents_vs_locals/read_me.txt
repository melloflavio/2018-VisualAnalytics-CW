Time period: 05/11/2012 - 24/10/2013
Number of trajectories: ???

Division into visitors and residents
Visitors: had tweets in less than 30 different days (N=???)
Residents: had tweets in at least 30 different days  (N=???)

Territory division:  606 Voronoi polygons obtained using a sample of 39610 points 
from Twitter (21390) and Flickr (18220); variable cluster radius from 2500 to 150m 
(division of unbalanced point groups + division of groups with >=500 points).

Aggregation
Data from the visitors and residents were aggregated separately by the Voronoi cells and 
hours of the week (i.e., tweets from all weeks were counted as in a single week).